﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Text;
using System.Threading;

class WorkQueue : WorkQueue<Action>
{
    public WorkQueue() : this(16, -1) { }
    public WorkQueue(int thread)
        : this(thread, -1)
    {
    }
    public WorkQueue(int thread, int capacity)
    {
        base.Thread = thread;
        base.Capacity = capacity;
        base.Process += delegate (Action ah) {
            ah();
        };
    }
}

class WorkQueue<T> : IDisposable
{
    public delegate void WorkQueueProcessHandler(T item);
    public event WorkQueueProcessHandler Process;

    private int _thread = 16;
    private int _capacity = -1;
    private int _work_index = 0;
    private ConcurrentDictionary<int, WorkInfo> _works = new ConcurrentDictionary<int, WorkInfo>();
    private ConcurrentQueue<T> _queue = new ConcurrentQueue<T>();

    public WorkQueue() : this(16, -1) { }
    public WorkQueue(int thread)
        : this(thread, -1)
    {
    }
    public WorkQueue(int thread, int capacity)
    {
        _thread = thread;
        _capacity = capacity;
    }

    public void Enqueue(T item)
    {
        if (_capacity > 0 && _queue.Count >= _capacity) throw new Exception($"队列数量大于(capacity)设置值：{_capacity}");
        _queue.Enqueue(item);
        foreach (WorkInfo w in _works.Values)
        {
            if (w.IsWaiting)
            {
                w.Set();
                return;
            }
        }
        if (_works.Count < _thread)
        {
            if (_queue.Count > 0)
            {
                int index = Interlocked.Increment(ref _work_index);
                var work = new WorkInfo();
                _works.TryAdd(index, work);

                new Thread(delegate () {
                    while (isdisposed == false)
                    {
                        if (_queue.TryDequeue(out var de))
                        {
                            try
                            {
                                this.OnProcess(de);
                            }
                            catch
                            {
                            }
                        }
                        if (_queue.Count == 0)
                        {
                            if (work.WaitOne(TimeSpan.FromSeconds(20))) continue;
                            if (_queue.Count == 0) break;
                        }
                    }
                    _works.TryRemove(index, out var oldw);
                    work.Dispose();
                }).Start();
            }
        }
    }

    protected virtual void OnProcess(T item)
    {
        if (Process != null)
            Process(item);
    }

    #region IDisposable 成员

    bool isdisposed = false;
    object isdisposedLock = new object();
    public void Dispose()
    {
        if (isdisposed) return;
        lock (isdisposedLock)
        {
            if (isdisposed) return;
            isdisposed = true;
        }

        while (_queue.TryDequeue(out var de)) ;
        foreach (WorkInfo w in _works.Values)
            w.Dispose();
    }

    #endregion

    public int Thread
    {
        get => _thread;
        set
        {
            if (_thread != value)
                _thread = value;
        }
    }
    public int Capacity
    {
        get => _capacity;
        set
        {
            if (_capacity != value)
                _capacity = value;
        }
    }

    public int UsedThread => _works.Count;
    public int Queue => _queue.Count;

    public string Statistics
    {
        get
        {
            string value = string.Format(@"线程：{0}/{1}
队列：{2}

", _works.Count, _thread, _queue.Count);
            foreach (var k in _works.Keys)
            {
                WorkInfo w = null;
                if (_works.TryGetValue(k, out w))
                    value += string.Format(@"线程{0}：{1}
", k, w.IsWaiting);
            }
            return value;
        }
    }

    class WorkInfo : IDisposable
    {
        private ManualResetEvent _reset = new ManualResetEvent(false);
        private bool _isWaiting = false;

        public bool WaitOne(TimeSpan timeout)
        {
            if (isdisposed) return false;
            try
            {
                _reset.Reset();
                _isWaiting = true;
                return _reset.WaitOne(timeout);
            }
            catch { }
            return false;
        }
        public bool Set()
        {
            try
            {
                _isWaiting = false;
                return _reset.Set();
            }
            catch { }
            return false;
        }

        public bool IsWaiting => _isWaiting;

        bool isdisposed = false;
        object isdisposedLock = new object();
        public void Dispose()
        {
            if (isdisposed) return;
            lock (isdisposedLock)
            {
                if (isdisposed) return;
                isdisposed = true;
            }

            this.Set();
            _reset.Dispose();
        }
    }
}
