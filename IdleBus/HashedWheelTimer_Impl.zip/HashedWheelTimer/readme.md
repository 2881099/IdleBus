
源码来自：https://github.com/wangjia184/HashedWheelTimer

植入原因：为了支持 .net framework 4.0
