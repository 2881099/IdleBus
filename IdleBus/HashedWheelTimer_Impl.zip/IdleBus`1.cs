﻿using HWT;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;

/// <summary>
/// 空闲对象容器管理，可实现自动创建、销毁、扩张收缩，解决【实例】长时间占用问题
/// </summary>
public partial class IdleBus<T> : IDisposable where T : class, IDisposable
{

    ConcurrentDictionary<string, ItemInfo> _dic;
    ConcurrentDictionary<string, ItemInfo> _removePending;
    object _usageLock = new object();
    int _usageQuantity;
    TimeSpan _defaultIdle;
    HWT.HashedWheelTimer _timer;
    object _timerLock = new object();

    #region Dispose
    ~IdleBus() => Dispose();
    bool isdisposed = false;
    object isdisposedLock = new object();
    public void Dispose()
    {
        if (isdisposed) return;
        lock (isdisposedLock)
        {
            if (isdisposed) return;
            isdisposed = true;
        }
        foreach (var item in _removePending.Values) item.Dispose();
        foreach (var item in _dic.Values) item.Dispose();

        _removePending.Clear();
        _dic.Clear();
        _usageQuantity = 0;
        _timer?.Stop();
    }
    #endregion

    /// <summary>
    /// 按空闲时间1分钟，创建空闲容器
    /// </summary>
    public IdleBus() : this(TimeSpan.FromMinutes(1)) {}

    /// <summary>
    /// 指定空闲时间、创建空闲容器
    /// </summary>
    /// <param name="idle">空闲时间</param>
    public IdleBus(TimeSpan idle)
    {
        _dic = new ConcurrentDictionary<string, ItemInfo>();
        _removePending = new ConcurrentDictionary<string, ItemInfo>();
        _usageQuantity = 0;
        _defaultIdle = idle;
    }

    /// <summary>
    /// 根据 key 获得或创建【实例】（线程安全）<para></para>
    /// key 未注册时，抛出异常
    /// </summary>
    /// <param name="key"></param>
    /// <returns></returns>
    public T Get(string key)
    {
        if (isdisposed) throw new Exception($"{key} 实例获取失败，{nameof(IdleBus<T>)} 对象已释放");
        if (_dic.TryGetValue(key, out var item) == false)
        {
            var error = new Exception($"{key} 实例获取失败，因为没有注册");
            this.OnNotice(new NoticeEventArgs(NoticeType.Get, key, error, error.Message));
            throw error;
        }

        var now = DateTime.Now;
        var ret = item.GetOrCreate();
        var tsms = DateTime.Now.Subtract(now).TotalMilliseconds;
        this.OnNotice(new NoticeEventArgs(NoticeType.Get, key, null, $"{key} 实例获取成功 {item.activeCounter}次{(tsms > 5 ? $"，耗时 {tsms}ms" : "")}"));
        //this.ThreadLiveWatch(item); //这种模式采用 Sorted 性能会比较慢
        //this.ThreadScanWatch(item); //这种在后台扫描 _dic，定时要求可能没那么及时
        this.ResetTimeout(item);
        return ret;
    }

    #region HashedWheelTimer
    void ResetTimeout(ItemInfo item)
    {
        Interlocked.Exchange(ref _closeTimer, null)?.Cancel();
        var cancelTimeout = NewTimeout(item.idle, () =>
        {
            try
            {
                var now = DateTime.Now;
                if (item.Release(() => DateTime.Now.Subtract(item.lastActiveTime) > item.idle && item.lastActiveTime >= item.createTime))
                    //防止并发有其他线程创建，最后活动时间 > 创建时间
                    this.OnNotice(new NoticeEventArgs(NoticeType.AutoRelease, item.key, null, $"{item.key} ---自动释放成功，耗时 {DateTime.Now.Subtract(now).TotalMilliseconds}ms，{_usageQuantity}/{Quantity}"));
            }
            catch (Exception ex)
            {
                this.OnNotice(new NoticeEventArgs(NoticeType.AutoRelease, item.key, ex, $"{item.key} ---自动释放执行出错：{ex.Message}"));
            }
            ResetCloseTimer();
        });
        item.ResetCancelTimeout(cancelTimeout);
    }
    HWT.Timeout _closeTimer;
    void ResetCloseTimer()
    {
        if (_usageQuantity == 0 && _closeTimer == null)
        {
            var closeTimeout = NewTimeout(TimeSpan.FromSeconds(20), () =>
            {
                lock (_timerLock)
                {
                    _timer.Stop();
                    _timer = null;
                }
            });
            Interlocked.Exchange(ref _closeTimer, closeTimeout)?.Cancel();
        }
    }
    HWT.Timeout NewTimeout(TimeSpan timeout, Action action)
    {
        if (_timer == null)
            lock (_timerLock)
                if (_timer == null)
                    _timer = new HWT.HashedWheelTimer(tickDuration: TimeSpan.FromMilliseconds(200), ticksPerWheel: 100000, maxPendingTimeouts: 0);
        return _timer.NewTimeout(new NewTimeoutAction(action), timeout);
    }
    class NewTimeoutAction : HWT.TimerTask
    {
        Action _action;
        public NewTimeoutAction(Action action) => _action = action;
        public void Run(HWT.Timeout timeout) => _action?.Invoke();
    }
    #endregion

    /// <summary>
    /// 判断 key 是否注册
    /// </summary>
    /// <param name="key"></param>
    /// <returns></returns>
    public bool Exists(string key) => _dic.ContainsKey(key);

    /// <summary>
    /// 注册【实例】
    /// </summary>
    /// <param name="key"></param>
    /// <param name="create">实例创建方法</param>
    /// <returns></returns>
    public IdleBus<T> Register(string key, Func<T> create)
    {
        InternalRegister(key, create, null, true);
        return this;
    }
    public IdleBus<T> Register(string key, Func<T> create, TimeSpan idle)
    {
        InternalRegister(key, create, idle, true);
        return this;
    }
    public bool TryRegister(string key, Func<T> create) => InternalRegister(key, create, null, false);
    public bool TryRegister(string key, Func<T> create, TimeSpan idle) => InternalRegister(key, create, idle, false);

    public bool TryRemove(string key) => InternalRemove(key, false);

    /// <summary>
    /// 已创建【实例】数量
    /// </summary>
    public int UsageQuantity => _usageQuantity;
    /// <summary>
    /// 注册数量
    /// </summary>
    public int Quantity => _dic.Count;
    /// <summary>
    /// 通知事件
    /// </summary>
    public event EventHandler<NoticeEventArgs> Notice;

    bool InternalRegister(string key, Func<T> create, TimeSpan? idle, bool isThrow)
    {
        if (isdisposed) throw new Exception($"{key} 注册失败，{nameof(IdleBus<T>)} 对象已释放");
        var error = new Exception($"{key} 注册失败，请勿重复注册");
        if (_dic.ContainsKey(key))
        {
            this.OnNotice(new NoticeEventArgs(NoticeType.Register, key, error, error.Message));
            if (isThrow) throw error;
            return false;
        }

        if (idle == null) idle = _defaultIdle;
        //if (idle < TimeSpan.FromSeconds(5))
        //{
        //    var limitError = new Exception($"{key} 注册失败，{nameof(idle)} 参数必须 >= 5秒");
        //    this.OnNotice(new NoticeEventArgs(NoticeType.Register, key, limitError, limitError.Message));
        //    if (isThrow) throw error;
        //    return this;
        //}
        var added = _dic.TryAdd(key, new ItemInfo
        {
            ib = this,
            key = key,
            create = create,
            idle = idle.Value,
        });
        if (added == false)
        {
            this.OnNotice(new NoticeEventArgs(NoticeType.Register, key, error, error.Message));
            if (isThrow) throw error;
            return false;
        }
        this.OnNotice(new NoticeEventArgs(NoticeType.Register, key, null, $"{key} 注册成功，{_usageQuantity}/{Quantity}"));
        return true;
    }
    bool InternalRemove(string key, bool isThrow)
    {
        if (isdisposed) throw new Exception($"{key} 删除失败，{nameof(IdleBus<T>)} 对象已释放");
        if (_dic.TryRemove(key, out var item) == false)
        {
            var error = new Exception($"{key} 删除失败，因为没有注册");
            this.OnNotice(new NoticeEventArgs(NoticeType.Remove, key, error, error.Message));
            if (isThrow) throw error;
            return false;
        }

        Interlocked.Exchange(ref item.releaseErrorCounter, 0);
        item.lastActiveTime = DateTime.Now;

        void LazyRemove()
        {
            try
            {
                item.Release(() => true);
            }
            catch (Exception ex)
            {
                var tmp1 = Interlocked.Increment(ref item.releaseErrorCounter);
                this.OnNotice(new NoticeEventArgs(NoticeType.Remove, item.key, ex, $"{key} ---延时释放执行出错({tmp1}次)：{ex.Message}"));
                if (tmp1 < 5)
                    NewTimeout(TimeSpan.FromSeconds(60), LazyRemove);
            }
        }
        NewTimeout(TimeSpan.FromSeconds(60), LazyRemove);
        this.OnNotice(new NoticeEventArgs(NoticeType.Remove, item.key, null, $"{key} 删除成功，并且已标记为延时释放，{_usageQuantity}/{Quantity}"));
        return true;
    }

    void OnNotice(NoticeEventArgs e)
    {
        if (this.Notice != null) this.Notice(this, e);
        else Trace.WriteLine($"[{DateTime.Now.ToString("HH:mm:ss")}] 线程{Thread.CurrentThread.ManagedThreadId}：{e.Log}");
    }
}